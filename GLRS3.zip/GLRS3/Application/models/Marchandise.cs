﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.models
{
    class Marchandise
    {
        private int numero;
        private int poids;
        private int volume;




        public int marchandises()
        {

        };
        public string ToString()
        {

        };
      
       
    }
}
