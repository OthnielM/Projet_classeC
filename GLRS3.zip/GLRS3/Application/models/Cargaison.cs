﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.models
{
    class Cargaison
    {
        private int distance;
        private int marchandises;




        public int add()
        {

        };
        public int afficher()
        {

        };
        public int cargaison()
        {

        };
        public int cout()
        {

        };
        public int getMarchandises()
        {

        };
        public int getPoidsTotal()
        {

        };
        public int getVolumeTotal()
        {

        };
    }

}
