﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.models
{
    class CargaisonAerienne
    {
        private string cargaison;
        




        public string cargaisonAerienne()
        {

        };
        public string cout()
        {

        };
    }
}
