﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1.models
{
    class Compte
    {
        private static int nbreDecompteCree ;

        nbreDecompteCree++;
        public static int nbreDecompteCree { get => nbreDecompteCree; set => nbreDecompteCree = value; };


        public static int getNbreCompte()
        {
           return String.Format("Le nombre de comptes est {0}",nbreDecompteCree");
        };
    }

    


}
