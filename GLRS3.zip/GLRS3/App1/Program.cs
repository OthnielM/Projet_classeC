﻿using App1.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1
{
    class Program
    {
        static void Main(string[] args)
        {
            Compte c = new Compte();
            Console.WriteLine(String.Format("Nombre de compte est {0}", c.nbreDecompteCree));
        }
    }
}
